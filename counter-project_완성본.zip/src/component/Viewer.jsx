const Viewer = ({count}) => {
    return (
        <div>
            <div>현재 몬스터 수: </div>
            <h1>{count}</h1>
        </div>
    );
};

export default Viewer;